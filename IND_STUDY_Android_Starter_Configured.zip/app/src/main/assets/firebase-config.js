// IND STUDY Firebase web app configuration
// These are Firebase client configuration values, not admin credentials.
window.STUDY_DOST_FIREBASE_CONFIG = {
  apiKey: "AIzaSyBKamhLZxmKb48pJtBpRhVrrU77XdyT9vc",
  authDomain: "ind-study-ef711.firebaseapp.com",
  projectId: "ind-study-ef711",
  storageBucket: "ind-study-ef711.firebasestorage.app",
  messagingSenderId: "521872380073",
  appId: "1:521872380073:web:7926bd5ad1ef5a6138d9b8",
  measurementId: "G-SMCN4EVZV4"
};
