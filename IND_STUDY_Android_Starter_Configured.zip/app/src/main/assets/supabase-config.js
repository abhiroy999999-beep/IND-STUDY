// IND STUDY Supabase client configuration.
// Publishable key is intended for client-side use; never put a secret/service_role key here.
window.IND_STUDY_SUPABASE_CONFIG = {
  url: "https://hwzxbgqluloxvfrnvqee.supabase.co",
  publishableKey: "sb_publishable_HrMjU2u_eFz4M7iQ-oMAzg_c6lRv_hU"
};
