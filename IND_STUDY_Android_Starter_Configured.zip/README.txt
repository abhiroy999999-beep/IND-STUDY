IND STUDY - CONFIGURED ANDROID STARTER

Included:
- Android Studio starter project with a WebView app shell.
- Firebase web configuration for the user's Firebase project.
- Supabase project URL and publishable key configuration.
- Starter Firestore and Storage rules from the original starter.

IMPORTANT STATUS:
This is a configured STARTER / UI PROTOTYPE, not a completed production app.
The current demo UI is not fully wired to Firebase or Supabase. Real signup/login,
multi-user chat, groups, uploads, downloads, notifications, and moderation still
need implementation and testing. No APK has been built.

SECURITY:
- Do not add or share Supabase secret/service_role keys in this project.
- The Supabase secret key was shared in chat; revoke/rotate it in Supabase
  Project Settings before proceeding.
- Keep the study-files bucket private.
- Storage policies must be reviewed and aligned with the authentication provider.
  The earlier folder policy expects Supabase Auth user IDs, but the project currently
  uses Firebase Auth setup; do not assume Firebase UIDs equal Supabase UIDs.
- Do not publish open database or storage rules.

NEXT:
1. Open this folder in Android Studio on a computer.
2. Sync Gradle.
3. Wire the UI to Firebase Authentication and Firestore.
4. Implement a secure file access design between Firebase Auth and Supabase Storage.
5. Test with separate user accounts before public release.
6. Build > Build APK(s) only after implementation and testing.

Firebase project: ind-study-ef711
Supabase bucket: study-files
